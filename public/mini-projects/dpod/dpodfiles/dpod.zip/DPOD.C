/****************************************************************/
/****************************************************************/
/*                            DPOD.C                            */
/*                       (c) Samir Lohani                       */
/*                                                              */
/* This program controls the DPOD board                         */
/* It supports EEPROMS: 16kbit      - I2C                       */
/*                    : 256/512kbit - Extended I2C              */
/****************************************************************/
/****************************************************************/

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <time.h>
#include <dos.h>

#define COM1 0x3f8         /* COM1 base address */
#define COM2 0x2f8         /* COM2 base address */
#define IER 1              /* UART IER register offset */
#define FCR 2              /* UART FCR register offset */
#define LCR 3              /* UART LCR register offset */
#define MCR 4              /* UART MCR register offset */
#define MSR 6              /* UART MSR register offset */


#define VER 1.00           /* version number of this program (float) */
#define DATE "18-Jun-2001" /* and the corresponding date (string) */
#define BUS_ADDR 0xa0      /* bus address of I2C device */
#define BUS_DELAY 1        /* bus delay (hold time) in ms with -delay */
#define VCC_DELAY 2500     /* delay after Vcc on in ms */
#define CCITT_POLY 0x1021  /* CRC-CCITT polynomial */
#define MAX_HEX 5          /* Maximum permitted hex chars in hex string */
#define NUM_DPAGE 32       /* Maximum length of progress indicator */

/* Inline macros */

/* Nominal delay by utilising function call overhead */
#define FAST_DELAY { delay(0); delay(0); delay(0); }

#define F_CLOSE    if (fclose(datafile)!=0) printf("Error: cannot close file %s\n", argv[argc-1]);
#define ERR4_QUIT  stop(); v_off(); restore_port(); exit(4);
#define ERR5_QUIT  v_off(); restore_port(); exit(5);

/* Typedefs */
typedef unsigned short int USHORT;
typedef unsigned long int ULONG;

/* Function prototypes: support functions */
void crc_ccitt(USHORT, USHORT);
int xstrton(char *, ULONG *);

/* Function prototypes: I2C functions */
void start(void);
void stop(void);
unsigned char out_byte(unsigned char);
unsigned char inp_byte(int);
int ack_poll(unsigned char);
int dummy_write(USHORT, int);
unsigned char dev_addr(int, int, USHORT);
int reset_mem(void);

/* Function prototypes: RS232 port interface functions */
void init_port(void);
void restore_port(void);
void v_on(void);
void v_off(void);
unsigned char DCD_pinread(void);
unsigned char SDA_read(void);
void SCL_high(void);
void SCL_low(void);
void SDA_high(void);
void SDA_low(void);

/* Global variables */
int serport;               /* selected COM port base address */
unsigned char mcrmask;     /* mask for mcr register */
int busdelay;              /* bus delay hold time */
USHORT crc_accum;          /* accumulator for CRC-CCITT */

/* Enumerated constants */
enum { NOERR=0, NOACK, TIMEOUT, NOHEX, FORMERR };
enum { LOW=0, HIGH, JUMPER, NOJUMPER, IIC, EXTIIC, READ, WRITE, SLOW, FAST };


/****************************************************************/
/* Main program                                                 */
/****************************************************************/
int main(int argc, char *argv[])
{
 /* Assign default parameters */
 FILE *datafile;
 char devspec[16]="-512";  /* default is  AT24C512 */
 int devtype=EXTIIC;       /* default for AT24C512 */
 int opmode=READ;          /* default is  READ mode */
 ULONG  devcap=0x10000;    /* default for AT24C512 */
 USHORT devpage=128;       /* default for AT24C512 */
 ULONG b_start=0, b_length, b_temp;
 int i, temval, option=0;
 unsigned int dpage;
 time_t optime;

 serport=COM2;             /* default is COM2 */
 b_length=0;               /* if not specified, devcap will be assigned */
 busdelay=FAST;            /* default is fast bus */
 crc_accum=0;              /* reset CRC-CCITT accumulator */

 /* About software */
 printf("\nDPOD Version %.2f dated %s (c) Samir Lohani\n\n",VER, DATE);

 /* Read command line options */
 for (i=1; i<=(argc-2); i++)
   if      (strcmpi(argv[i],"-com1")==0)  serport=COM1;
   else if (strcmpi(argv[i],"-com2")==0)  serport=COM2;
   else if (strcmpi(argv[i],"-fast")==0)  busdelay=FAST;
   else if (strcmpi(argv[i],"-delay")==0) busdelay=SLOW;
   else if (strcmpi(argv[i],"-r")==0)     opmode=READ;
   else if (strcmpi(argv[i],"-w")==0)     opmode=WRITE;
   else if (strcmpi(argv[i],"-16")==0)
     { devtype=IIC; devcap=0x800; devpage=16; strcpy(devspec, argv[i]); }
   else if (strcmpi(argv[i],"-256")==0)
     { devtype=EXTIIC; devcap=0x8000; devpage=64; strcpy(devspec, argv[i]); }
   else if (strcmpi(argv[i],"-512")==0)
     { devtype=EXTIIC; devcap=0x10000; devpage=128; strcpy(devspec, argv[i]); }
   else if ((strstr(argv[i],"-s")==argv[i])||(strstr(argv[i],"-S")==argv[i])) {
     if ((temval=xstrton(argv[i],&b_start))==NOHEX) {
       option-=1;
       printf("Error: bad hex value in %s\n",argv[i]);
       }
     else if (temval==FORMERR) {
       option-=1;
       printf("Error: bad format in block start address parameter %s\n",argv[i]);
       printf("Note:  start address contains upto %d hex digits only\n",MAX_HEX);
       }
     }
   else if ((strstr(argv[i],"-l")==argv[i])||(strstr(argv[i],"-L")==argv[i])) {
     if ((temval=xstrton(argv[i],&b_length))==NOHEX) {
       option-=1;
       printf("Error: bad hex value in %s\n",argv[i]);
       }
     else if (temval==FORMERR) {
       option-=1;
       printf("Error: bad format in block length parameter %s\n",argv[i]);
       printf("Note:  block length  contains upto %d hex digits only\n",MAX_HEX);
       }
     }
   else {option-=1; printf("Error: illegal command line parameter %s\n",argv[i]);}
 if (option<0) exit(2);
 if (argc==1) {
   printf("Usage:\ndpod <options> <filename>\n");
   printf("Options supported:\n");
   printf("-com1\t-com2\t\tselect appropiate serial port\n");
   printf("-16\t-256\t-512\tselect EEPROM memory capacity\n");
   printf("-fast\t-delay\t\tselect fast or delayed bus timing\n");
   printf("-r\t-w\t\tselect read or write operation\n");
   printf("-sx..x\t\t\tstarting block address (upto %d hex digits)\n",MAX_HEX);
   printf("-lx..x\t\t\tread block length (upto %d hex digits)\n",MAX_HEX);
   printf("Default options:\t-com2, -512, -fast, -r, -s0 -l0\n");
   exit(1);
   }

 /* Ensure valid start address and block length */
 if (opmode==WRITE)
   b_length=0;             /* ignore for -w */
 else if (b_length==0)
   b_length=devcap;        /* select entire device */
 if (b_start+b_length>devcap) {
   printf("Error: device capacity exceeded\n");
   exit(3);
   }

 /* List out operating parameters */
 printf("\n************** Operating Parameters **************\n");
 printf("Serial port used:\t\t%s\n",(serport==COM1)?" com1":" com2");
 printf("Dpod EEPROM identifier:\t\t %s\n",devspec);
 printf("Dpod bus access timing:\t\t%s\n",(busdelay==SLOW)?" delay":" fast");
 printf("Operation selected:\t\t%s\n",(opmode==READ)?" read dpod":" write dpod");
 printf("Block start Address:\t\t %x %.4x hex\n",(unsigned int) (b_start>>16),(unsigned int) (b_start%0x10000));
 if (opmode==READ)
   printf("Read block length:\t\t %x %.4x hex\n",(unsigned int) (b_length>>16),(unsigned int) (b_length%0x10000));
 init_port();              /* initialise serial port */
 v_on();                   /* switch on Vcc */
 delay(VCC_DELAY);         /* wait for Vcc to stabilise */
 printf("DCD Jumper status:\t\t%s\n",(DCD_pinread()==JUMPER)?" detected":" not detected");
 if (reset_mem()==NOACK) {
   printf("Error: dpod not responding during RESET\n");
   ERR4_QUIT
   }
 stop();
 dpage=devcap/NUM_DPAGE;
 printf("\nOperation Progress (  <.> = %u bytes  ):\n",dpage);

 /* Write file to EEPROM */
 if (opmode==WRITE) {
   if ((datafile=fopen(argv[argc-1],"rb"))== NULL) {
     printf("Error: cannot open file %s\n",argv[argc-1]);
     ERR5_QUIT
     }
   b_temp=b_start;
   while((temval=fgetc(datafile))!=EOF) {
     if (b_length==0) {              /* 1st data? */
       if (dummy_write(b_temp, devtype)==NOACK) {
	 printf("\nError: ack not received for device addr to dpod\n");
	 F_CLOSE
	 ERR4_QUIT
	 }
       }
     else if (b_temp%devpage==0)     /* new page? */
       if (dummy_write(b_temp, devtype)==NOACK) {
	 printf("\nError: ack not received for device addr to dpod\n");
	 F_CLOSE
	 ERR4_QUIT
	 }
     if (out_byte(temval)==HIGH) {   /* write byte */
       printf("\nError: ack not received for data write to dpod\n");
       F_CLOSE
       ERR4_QUIT
       }
     b_length++;
     b_temp++;
     crc_ccitt(temval, CCITT_POLY);  /* update CRC */
     if (b_temp%devpage==0) {        /* last page data? */
       stop();
       if (ack_poll(dev_addr(devtype, WRITE, b_temp))==TIMEOUT) {
	 printf("\nError: acknowledge polling timed out\n");
	 F_CLOSE
	 ERR4_QUIT
	 }
       }
     if (b_temp%dpage==0)
       printf(".");
     }
   printf("\n\n");
   if (b_temp%devpage!=0) {
     stop();
     if (ack_poll(dev_addr(devtype, WRITE, b_temp))==TIMEOUT) {
	 printf("Error: acknowledge polling timed out\n");
	 F_CLOSE
	 ERR4_QUIT
	 }
     }
   printf("Write block length:\t\t %x %.4x hex from file %s\n",(unsigned int) (b_length>>16), (unsigned int) (b_length%0x10000), argv[argc-1]);
   printf("Next free address: \t\t %x %.4x hex\n",(unsigned int) ((b_start+b_length)>>16), (unsigned int) ((b_start+b_length)%0x10000));
   }

 /* Sequential read from EEPROM to file */
 else {
   if ((datafile=fopen(argv[argc-1],"wb"))== NULL) {
     printf("Error: cannot open file %s\n",argv[argc-1]);
     ERR5_QUIT
     }
   if (dummy_write(b_start, devtype)==NOACK) {
     printf("Error: ack not received for device addr to dpod\n");
     F_CLOSE
     ERR4_QUIT
     }
   start();
   if (out_byte(dev_addr(devtype, READ, b_start))==HIGH) {
     printf("Error: ack not received for device addr to dpod\n");
     F_CLOSE
     ERR4_QUIT
     }
   b_temp=0;
   while (--b_length) {
     temval=inp_byte(LOW);
     if (fputc(temval,datafile)==EOF) {
       printf("\nError: write error in file %s\n", argv[argc-1]);
       F_CLOSE
       ERR4_QUIT
       }
     b_temp++;
     crc_ccitt(temval, CCITT_POLY);  /* update CRC */
     if ((b_start+b_temp)%dpage==0)
       printf(".");
     }
   temval=inp_byte(HIGH);
   if (fputc(temval,datafile)==EOF) {
     printf("\nError: write error in file %s\n", argv[argc-1]);
     F_CLOSE
     ERR4_QUIT
     }
   crc_ccitt(temval, CCITT_POLY);    /* update CRC */
   stop();
   b_temp++;
   if ((b_start+b_temp)%dpage==0)
     printf(".");
   printf("\n\n");
   }

 /* Finally ... */
 printf("File CRC CCITT word:\t\t %.4x hex\n",(unsigned int) crc_accum);
 printf("Datafile filespec:\t\t %s\n", argv[argc-1]);
 F_CLOSE                   /* close file */
 optime=time(NULL);
 printf("Operation successful:\t\t %s\n", ctime(&optime));
 v_off();                  /* switch off Vcc */
 restore_port();           /* cleanup */
 return 0;
}

/****************************************************************/
/* SUPPORT FUNCTIONS                                            */
/****************************************************************/

/* Updates  CCITT CRC accumulator (global variable crc_accum) */
/* Parameter f_data: MSB 8 bits zero, LSB is data byte  */
/* Parameter crc_poly: crc polynomial */
void crc_ccitt(USHORT f_data, USHORT crc_poly)
{
 int c_count;
 f_data<<=8;               /* shift out 8 zero bits at MSB */
 for (c_count=0; c_count<8; c_count++) {
   if ((f_data^crc_accum)&0x8000)
     crc_accum=(crc_accum<<1)^crc_poly;
   else
     crc_accum<<=1;
   f_data<<=1;
   }
}

/* Assign hex string value */
/* Parameter xstr: pointer to hex string whose 1st two chars are identifiers */
/* Parameter xval: pointer to variable where value is assigned */
/* Return value: NOERR on success, NOHEX on bad hex, FORMERR on format error */
int xstrton(char *xstr, ULONG *xval)
{
 int ptr=0;
 int ch;
 *xval=0;
 do {
    ch=xstr[(ptr++)+2];
    if (isxdigit(ch)==0) {
      *xval=0;
      return NOHEX;
      }
    if (isdigit(ch))
      *xval=16*(*xval)+(ch-'0');
    else
      *xval=16*(*xval)+(tolower(ch)-'a'+10);
    } while (xstr[ptr+2]!='\0');
  if (ptr>MAX_HEX)
    return FORMERR;
  else
    return NOERR;
}

/****************************************************************/
/* I2C FUNCTIONS                                                */
/* Port setup and Vcc control must be done separately in main() */
/****************************************************************/

/* Generate I2C start condition */
void start(void)
{
 SDA_high();
 SCL_high();
 SDA_low();
 SCL_low();
}

/* Generate I2C stop condition */
void stop(void)
{
 SDA_low();
 SCL_high();
 SDA_high();
}

/* Output byte on I2C bus */
/* I2C start and stop conditions to be issued separately */
/* Parameter byte: byte to be output on I2C bus */
/* Return value: receiver acknowledge bit {LOW, HIGH} */
unsigned char out_byte(unsigned char byte)
{
 unsigned char sda_status;
 char bitcount;
 for(bitcount=0; bitcount<8; bitcount++) {
   if ((byte&0x80)==0)
     SDA_low();
   else
     SDA_high();
   byte=byte<<1;
   SCL_high();
   SCL_low();
   }                       /* shift bits, MSB first */
 SDA_high();               /* release SDA */
 SCL_high();
 sda_status=SDA_read();    /* read receiver acknowledge bit */
 SCL_low();
 return sda_status;
}

/* Receive byte on I2C bus */
/* I2C start and stop conditions to be issued separately */
/* Parameter ack: value of acknowledge bit given on 9th clk {LOW,HIGH} */
/* Return value:byte received from I2C bus */
unsigned char inp_byte(int ack)
{
 char bitcount;
 unsigned char inbyte=0;
 SDA_high();               /* release SDA */
 for(bitcount=0; bitcount<8; bitcount++) {
   inbyte=inbyte<<1;
   SCL_high();
   if (SDA_read()==HIGH)
     inbyte=inbyte|0x1;
   SCL_low();
   }
 if (ack==LOW)
   SDA_low();
 SCL_high();
 SCL_low();
 return inbyte;
}

/* Acknowledge polling sequence */
/* Parameter slave_addr: 8-bit slave address for I2C device */
/* Return value: NOERR on success, TIMEOUT if timed out */
/* Timeout provided is CLK_TCK clock ticks, i.e. 1 second */
int ack_poll(unsigned char slave_addr)
{
 unsigned char poll;
 clock_t t_start;
 t_start=clock();
 do {
   start();
   poll=out_byte(slave_addr);
   stop();
   } while (poll==HIGH && ((clock() - t_start)<CLK_TCK));
 if (poll==HIGH)
   return TIMEOUT;
 else
   return NOERR;
}

/* Compute 8-bit I2C device address */
/* Parameter dtype: device type {IIC, EXTIIC } */
/* Parameter dmode: device mode {READ, WRITE } */
/* Parameter addr: memory cell address */
/* Return value: 8-bit I2C device address */
unsigned char dev_addr(int dtype, int dmode, USHORT addr)
{
 unsigned char daddr;
 if (dtype==IIC)
   daddr=((addr>>7)&0xe)|(BUS_ADDR & 0xf0);
 else
   daddr=BUS_ADDR & 0xfe;
 if (dmode==READ)
   daddr=daddr|0x1;        /* insert read bit at LSB */
 return daddr;
}

/* Perform a dummy write sequence */
/* Outputs: <start> - <address byte(s)> */
/* Parameter maddr: address of byte */
/* Parameter mtype: device type {IIC, EXTIIC } */
/* Return value: NOERR on success, NOACK on no device acknowledge */
int dummy_write(USHORT maddr, int mtype)
{
 unsigned char temp;
 start();                  /* issue I2C start condition */
 if (out_byte(dev_addr(mtype,WRITE,maddr))==HIGH)
   return NOACK;           /* issue slave address, return if no ack */
 if (mtype==IIC) {
   temp=maddr%256;
   if (out_byte(temp)==HIGH)
     return NOACK;
   else
     return NOERR;         /* issue address byte, return as per ack */
   }
 else {
   temp=maddr>>8;
   if (out_byte(temp)==HIGH)
     return NOACK;         /* issue address byte 1, return if no ack */
   temp=maddr%256;
   if (out_byte(temp)==HIGH)
     return NOACK;
   else
     return NOERR;         /* issue address byte 0, return as per ack */
   }
}

/* Reset memory */
/* Use at interruption of protocol */
/* Return value: NOERR on success, NOACK on no device acknowledge */
/* If success, returns with I2C start condition issued */
int reset_mem(void)
{
 int cycle=0,ack;
 SDA_high();
 SCL_high();
 do {
   if ((ack=SDA_read())==LOW) {
     SCL_low();
     SCL_high();
     }
   cycle++;
   } while ((ack==LOW)&&(cycle<9));
 if (ack==HIGH) {
   start();
   return NOERR;
   }
 else
   return NOACK;
}

/****************************************************************/
/* RS232 port interface                                         */
/* These are low level hardware functions                       */
/* Hardware assumed: 8250/16550/compatible UART, DPOD circuit   */
/****************************************************************/

/* Initialise serial port */
void init_port(void)
{
 outportb(serport+LCR,inportb(serport+LCR)&0x3f);
 outportb(serport+IER,0x0);          /* disable interrupts */
 outportb(serport+FCR,0x0);          /* disable FIFO */
 mcrmask=inportb(serport+MCR)&0xc;   /* mcrmask with SCL,SDA high */
 outportb(serport+MCR,mcrmask);      /* set SCL,SDA lines */
}

/* Restore serial port settings (cleanup) */
void restore_port(void)
{
 outportb(serport+LCR,inportb(serport+LCR)&0x3f);
 mcrmask=inportb(serport+MCR)&0xc;   /* mcrmask with SCL,SDA high */
 outportb(serport+MCR,mcrmask);      /* set SCL,SDA lines */
}

/* Switch DPOD Vcc on */
/* Switches TXD line to SPACE condition */
void v_on(void)
{
 outportb(serport+LCR,(inportb(serport+LCR)&0xbf)|0x40); /* set break bit */
}

/* Switch DPOD Vcc off */
/* Switches TXD line to MARK condition */
void v_off(void)
{
 outportb(serport+LCR,(inportb(serport+LCR)&0xbf));      /* reset break bit */
}

/* Read DCD pin */
/* Return value: {JUMPER, NOJUMPER} */
unsigned char DCD_pinread(void)
{
 return ((inportb(serport+MSR)>>7)&0x1==1)?JUMPER:NOJUMPER ;
}

/* Read SDA */
/* Polls CTS pin */
/* Return value: {LOW, HIGH} */
unsigned char SDA_read(void)
{
 return ((inportb(serport+MSR)>>4)&0x1==1)?LOW:HIGH ;
}

/* Set SCL high */
/* Sets corresponding level to RTS pin */
void SCL_high(void)
{
 mcrmask=mcrmask&0xd;
 outportb(serport+MCR,mcrmask);
 if (busdelay==SLOW)
   delay(BUS_DELAY);
 else
   FAST_DELAY
}

/* Set SCL low */
/* Sets corresponding level to RTS pin */
void SCL_low(void)
{
 mcrmask=mcrmask|0x2;
 outportb(serport+MCR,mcrmask);
 if (busdelay==SLOW)
   delay(BUS_DELAY);
 else
   FAST_DELAY
}

/* Set SDA high */
/* Sets corresponding level to DTR pin */
void SDA_high(void)
{
 mcrmask=mcrmask&0xe;
 outportb(serport+MCR,mcrmask);
 if (busdelay==SLOW)
   delay(BUS_DELAY);
 else
   FAST_DELAY
}

/* Set SDA low */
/* Sets corresponding level to DTR pin */
void SDA_low(void)
{
 mcrmask=mcrmask|0x1;
 outportb(serport+MCR,mcrmask);
 if (busdelay==SLOW)
   delay(BUS_DELAY);
 else
   FAST_DELAY
}
