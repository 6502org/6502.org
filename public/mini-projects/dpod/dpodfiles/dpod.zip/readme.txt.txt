
DPOD Version 1.00 dated 18-Jun-2001 (c) Samir Lohani

This file contains usage notes for dpod.exe 

* Run dpod.exe without any parameters to get a listing of the command line parameters supported.
* The command line parameters supported are:

Usage:
dpod <options> <filename>
Options supported:
-com1	-com2		select appropiate serial port
-16	-256	-512	select EEPROM memory capacity
-fast	-delay		select fast or delayed bus timing
-r	-w		select read or write operation
-sx..x			starting block address (upto 5 hex digits)
-lx..x			read block length (upto 5 hex digits)
Default options:	-com2, -512, -fast, -r, -s0 -l0


* -com1 or -com2 select the serial port to which dpod is plugged in. The default is -com2

* -16 , -256 & -512 select the EEPROM memory capacity. This is derived from the EEPROM chip number as follows:

	EEPROM installed	option
	24C16 / 24C17		-16
	AT24C256		-256
	AT24C512		-512	<default>

* -fast selects minimal bus delay after setting high or low level of SCK or SDA <default>
  -delay selects a delay of 1 ms after setting high or low level of SCK or SDA

* -r selects "read data from dpod" operation
  -w selects "write data to dpod" operation

* The EEPROM is conceptually thought of as a contiguous array of byte locations. The address of the first location is 0 and the address of the last location depends on the device capacity ( 07ff hex for -16, 7fff hex for -256 and ffff hex for -512 ). Any block of data stored in the EEPROM is identified by its <start address> and <block length>. The <start address> is the EEPROM array address where the first byte of the data block is located and <block length> is the number of bytes in the data block. A <block length> of 0 if specified sets the maximum block length permitted in the memory array. Thus <start address>=0 and <block length>=0 would select the entire memory array.

* -sx..x and -lx..x are used to specify the <start address> and <block length> respectively. The default is -s0 and -l0.
For write operations, only -sx..x may be given. -lx..x if given is ignored. The <filename> specified is copied to the EEPROM array at the <start address> given. The length of block is determined from the <filename> and reported in the operation summary.
For reading the same file back, -sx..x and -lx..x must correspond to the values at the time of write operation ( a complete report is prepared by the dpod in operation summary ). The file CRC-CCITT word will also be the same for read and write operations if there are no errors.
Note that starting block address and block length are specified in hex and can be upto 5 hex digits. Superfluous zeroes may be omitted.

* <filename> : This MUST be specified in the dpod command. The <filename> can be any valid DOS filespec for a particular file. The last parameter of the dpod command is always assumed to be the <filename>.

* Examples:
 dpod eeprom.txt			:Read entire contents of dpod to the file eeprom.txt
 dpod -w eeprom.txt			:Write the same file back to dpod 
 dpod -com1 -256 -w -s4000 readme.txt	:Write readme.txt from address 4000 hex  (-com1, -256)
 dpod -com1 -256 -r -s4000 -l100 data1	:Read 100 hex bytes at 4000 hex to data1 (-com1, -256)

* This program should be run in MS-DOS command prompt mode only. It may not run properly in the Windows DOS Box unless the COM port driver specially has DOS Box support.

*************************************************************************************************
