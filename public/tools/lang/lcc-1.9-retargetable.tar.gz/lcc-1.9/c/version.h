/* Wed Sep 9 10:12:57 EDT 1992 */
#define VERSION ((1<<8)|9)
