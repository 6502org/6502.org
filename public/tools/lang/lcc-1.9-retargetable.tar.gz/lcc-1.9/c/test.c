

void main(void)

{
	printf("%d\n", -5 % 2);
}
