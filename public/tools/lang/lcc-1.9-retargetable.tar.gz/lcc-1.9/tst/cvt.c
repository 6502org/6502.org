signed char c, c1, c2;
signed short s;
signed int i, i1, i2;
unsigned char C;
unsigned short S;
unsigned int I;
float f, f1, f2;
double d, d1, d2;

main()
{
	c=1;     s=c;i=c;C=c;S=c;I=c;f=c;d=c; printf("%d %d %d %d %d %d %f %f\n", c, s, i, C, S, I, f, d);
	s=2; c=s;    i=s;C=s;S=s;I=s;f=s;d=s; printf("%d %d %d %d %d %d %f %f\n", c, s, i, C, S, I, f, d);
	i=3; c=i;s=i;    C=i;S=i;I=i;f=i;d=i; printf("%d %d %d %d %d %d %f %f\n", c, s, i, C, S, I, f, d);
	C=4; c=C;s=C;i=C;    S=C;I=C;f=C;d=C; printf("%d %d %d %d %d %d %f %f\n", c, s, i, C, S, I, f, d);
	S=5; c=S;s=S;i=S;C=S;    I=S;f=S;d=S; printf("%d %d %d %d %d %d %f %f\n", c, s, i, C, S, I, f, d);
	I=6; c=I;s=I;i=I;C=I;S=I;    f=I;d=I; printf("%d %d %d %d %d %d %f %f\n", c, s, i, C, S, I, f, d);
	f=7; c=f;s=f;i=f;C=f;S=f;I=f;    d=f; printf("%d %d %d %d %d %d %f %f\n", c, s, i, C, S, I, f, d);
	d=8; c=d;s=d;i=d;C=d;S=d;I=d;f=d;     printf("%d %d %d %d %d %d %f %f\n", c, s, i, C, S, I, f, d);
}
