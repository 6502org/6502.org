

void main(void)

{
	int a = 0;

	printf("%d\n", (a + 23) & 0xfffffffc);
}

