

void main(void)

{
	int a = 0, i;

	for (i=0; i<256; i++)
		printf("Hi, I'm an accumulator machine! %d\n", i);
}

