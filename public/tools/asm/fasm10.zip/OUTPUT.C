
/*
** FASM - 6502 assembler
** Copyright (c) 2000 by Toshiyasu Morita
** Released under the terms of the GNU Public License
** See the file COPYING for details
*/

#include <stdio.h>
#include <stdlib.h>

#include "fasm.h"
#include "proto.h"


/*
** Open output buffer
*/

void Open_Output_Buffer()

{

	object_buf_bytes = 0;

	switch (output_format) {


		case 0:	/* Motorola S-format */

			if ( (outfile = fopen(output_filename, "wt")) == NULL ) {

				printf("Error opening output file\n");
				exit(ERROR);
				}

			break;


		}

}

/*
** Flush object buffer to file
*/

void Flush_Output_Buffer()

{
	int i, checksum;



	if (object_buf_bytes) {

		switch(output_format) {

			case 0:	/* Motorola S-format */

				fprintf(outfile, "S1%.2X", (object_buf_bytes + 3) & 0x0ff );

	  	  		fprintf(outfile, "%.4X", last_address & 0x0ffff );

	  	 	  	checksum = (last_address & 0x0ff) + ((last_address >> 8) & 0x0ff) +
		 					object_buf_bytes + 3;

	 	  		for (i=0; i<object_buf_bytes; i++) {

					fprintf(outfile, "%.2X", object_buffer[i] & 0x0ff);

		 			checksum += object_buffer[i];
		 			}

	  			fprintf(outfile, "%.2X\n", (checksum ^ 0x0ff) & 0x0ff);

				break;

			}

		last_address += object_buf_bytes;

		object_buf_bytes = 0;
		}
}


/*
** Close output file
*/

void Close_Output_Buffer()

{

	Flush_Output_Buffer();

	switch (output_format) {

		case 0:	/* Motorola S-format */

			fprintf(outfile, "S9030000FC\n");
			break;


		}


	fclose(outfile);

}


/*
** Output data
*/

void Output_Data()

{
	int i;


	for (i=0; i<byte_len;) {

		if (object_buf_bytes == 32)

			Flush_Output_Buffer();

		object_buffer[object_buf_bytes++] = byte[i++];

		}
}