
/*
** FASM - 6502 assembler
** Copyright (c) 2000 by Toshiyasu Morita
** Released under the terms of the GNU Public License
** See the file COPYING for details
*/

/*
** Header files
*/

#include <stdio.h>
#include <stdlib.h>

#include "proto.h"
#include "fasm.h"

/*
** Identify pseudo-op
*/

int Identify_PseudoOp()


{

	char c, *buffer = operator;
	UBYTE state = 0;

	/* State table has data to identify:
	 *
	 * ORG 		= 200
	 * EQU 		= 201
	 * DS 		= 202
	 * DB  		= 203
	 * DW       = 204
	 * INCLUDE  = 205
	 * LIST     = 206
	 * NOLIST   = 207
	 * INCBIN   = 208
	 * DL       = 209
	 *
	 */


	static UBYTE state_table[33][27] = {

/*           a   b   c   d   e   f   g   h   i   j   k   l   m   n   o   p   q   r   s   t   u   v   w   x   y   z  00  */

/*   0 */    0,  0,  0,  7,  4,  0,  0,  0, 11,  0,  0, 18,  0, 22,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*   0 */
/*   1 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  2,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*   1 */
/*   2 */    0,  0,  0,  0,  0,  0,  3,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*   2 */
/*   3 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,200,  /*   3 */
/*   4 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  5,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*   4 */
/*   5 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  6,  0,  0,  0,  0,  0,  0,  /*   5 */
/*   6 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,201,  /*   6 */
/*   7 */    0,  9,  0,  0,  0,  0,  0,  0,  0,  0,  0, 31,  0,  0,  0,  0,  0,  0,  8,  0,  0,  0, 10,  0,  0, 32,  0,  /*   7 */
/*   8 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,202,  /*   8 */
/*   9 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,203,  /*   9 */
/*  10 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,204,  /*  10 */
/*  11 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 12,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*  11 */
/*  12 */    0,  0, 13,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*  12 */
/*  13 */    0, 28,  0,  0,  0,  0,  0,  0,  0,  0,  0, 14,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*  13 */
/*  14 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 15,  0,  0,  0,  0,  0,  0,  /*  14 */
/*  15 */    0,  0,  0, 16,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*  15 */
/*  16 */    0,  0,  0,  0, 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*  16 */
/*  17 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,205,  /*  17 */
/*  18 */    0,  0,  0,  0,  0,  0,  0,  0, 19,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*  18 */
/*  19 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 20,  0,  0,  0,  0,  0,  0,  0,  0,  /*  19 */
/*  20 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 21,  0,  0,  0,  0,  0,  0,  0,  /*  20 */
/*  21 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,206,  /*  21 */
/*  22 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 23,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*  22 */
/*  23 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 24,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*  23 */
/*  24 */    0,  0,  0,  0,  0,  0,  0,  0, 25,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*  24 */
/*  25 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 26,  0,  0,  0,  0,  0,  0,  0,  0,  /*  25 */
/*  26 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 27,  0,  0,  0,  0,  0,  0,  0,  /*  26 */
/*  27 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,207,  /*  27 */
/*  28 */    0,  0,  0,  0,  0,  0,  0,  0, 29,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*  28 */
/*  29 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 30,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  /*  29 */
/*  30 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,208,   /*  30 */
/*  31 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,209,
/*  32 */    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,210
		};

	while (state < 200) {

		if ( (c = Convert_Character(*buffer++)) == -1)
			return(-1);


		if ( !(state = state_table[state][c]) )
			return(-1);

		}

	return(state - 200);

}

/*
** Do Pseudo-op for Pass 1
*/

int Do_PseudoOp_Pass1(int pseudo_op)

{

	char c, *buffer = operand;

	FILE *temp_file;


	switch(pseudo_op) {

		case 0: /* ORG */

			current_address = Expression_Analyzer(operand);
			valid_label = FALSE;
			return;


		case 1: /* EQU */

			if (Find_Symbol(label) != UNKNOWN) {

				error_text = "Redefined label";
				error_flag = TRUE;
				}

			else

				Add_Symbol(label, Expression_Analyzer(operand));

			valid_label = FALSE;
			return;


		case 2: /* DS  */

			skip_to_address = current_address + Expression_Analyzer(buffer);
			return;


		case 3: /* DB  */

			while (c = *buffer++)
				if (c == ',')
					byte_len++;

			byte_len++;
			return;


		case 4: /* DW  */

			while (c = *buffer++)
				if (c == ',')
					byte_len++;

			byte_len = (++byte_len << 1);
			return;


		case 5: /* INCLUDE */

			Push_File_Status();

			return;


		case 6: /* LIST    */
		case 7: /* NOLIST  */

			return;

		case 8: /* INCBIN  */

			byte_len;

			if ( (temp_file = fopen(operand, "rb")) == NULL )

				printf("Couldn't include file %s\n", operand);

			else {

				c = fgetc(temp_file);

				while ( !feof(temp_file) ) {

					byte_len++;

					c = getc(temp_file);
					}

				fclose(temp_file);
				}

			return;

		case 9: /* DL	*/

			while (c = *buffer++)
				if (c == ',')
					byte_len++;

			byte_len = (++byte_len) * 3;
			return;

		case 10: /* DZ  */

			while (c = *buffer++)
				if (c == ',')
					byte_len++;

			byte_len++;
			return;


		default: /* Shouldn't happen! */

			printf("Internal assembler error!\n");
			printf("Do_PseudoOp_Pass1: Unknown pseudo-op received! (%d)\n", pseudo_op);

			return;

		}

}

/*
** Do Pseudo-Op for Pass 2
*/

void Do_PseudoOp_Pass2(int pseudo_op)

{

	char c, *source, *dest, *buffer = operand;
	int temp, count = 0;
    long long_temp;

	int inc_length;

	FILE *temp_file;


	switch(pseudo_op) {

		case 0: /* ORG */

			Flush_Output_Buffer();
			last_address = skip_to_address = Expression_Analyzer(operand);
			valid_label = FALSE;
			return;


		case 1: /* EQU */

			valid_label = FALSE;
			return;


		case 2: /* DS  */

			skip_to_address = current_address + Expression_Analyzer(buffer);
			Flush_Output_Buffer();
			last_address = skip_to_address;
			return;


		case 3: /* DB  */

			source = operand;

			while (*source) {

				dest = alt_buffer;

					while ( (*source != ',') && (*source) )
		  				*dest++ = *source++;

				*dest = NULL;

				byte[byte_len++] = Expression_Analyzer(alt_buffer) & 0x0ff;

				if (*source)	/* skip past comma but not null */
					source++;
				}

			return;


		case 4: /* DW  */

			source = operand;

			while (*source) {

				dest = alt_buffer;

					while ( (*source != ',') && (*source) )
						*dest++ = *source++;

				*dest = NULL;

				temp = Expression_Analyzer(alt_buffer);

				byte[byte_len++] = temp & 0x0ff;
				byte[byte_len++] = (temp >> 8) & 0x0ff;

				if (*source)	/* Skip past comma but not null */
					source++;
				}

			return;


		case 5: /* INCLUDE */

			Push_File_Status();

			return;


		case 6: /* LIST    */

			list_flag = TRUE;
			return;


		case 7: /* NOLIST  */

			list_flag = FALSE;
			return;

		case 8: /* INCBIN  */

			if ( (temp_file = fopen(operand, "rb")) != NULL ) {

				c = fgetc(temp_file);

				while ( !feof(temp_file) ) {

					byte[byte_len++] = c;
					c = fgetc(temp_file);
					}

				fclose(temp_file);

				}

			else
				printf("Couldn't include file %s\n", operand);

            return;

        case 9: /* DL   */

            source = operand;

            while (*source) {

                dest = alt_buffer;

                    while ( (*source != ',') && (*source) )
                        *dest++ = *source++;

                *dest = NULL;

                long_temp = Expression_Analyzer(alt_buffer);

                byte[byte_len++] = long_temp & 0x0ff;
                byte[byte_len++] = (long_temp >> 8) & 0x0ff;
                byte[byte_len++] = (long_temp >>16) & 0x0ff;

                if (*source)    /* Skip past comma but not null */
                    source++;
                }

			return;

		case 10: /* DZ	*/

			source = operand;

			while (*source) {

				dest = alt_buffer;

					while ( (*source != ',') && (*source) )
						*dest++ = *source++;

				*dest = NULL;

				long_temp = Expression_Analyzer(alt_buffer);

				byte[byte_len++] = (long_temp >>16) & 0x0ff;

				if (*source) 	/* Skip past comma but not null */
					source++;
				}

			return;

		default: /* Shouldn't happen! */

			printf("Internal assembler error!\n");
			printf("Do_PseudoOp_Pass2: Unknown pseudo-op received! (%d)\n", pseudo_op);

			return;

		}

}






