
/*
** FASM - 6502 assembler
** Copyright (c) 2000 by Toshiyasu Morita
** Released under the terms of the GNU Public License
** See the file COPYING for details
*/

/*
** Header files
*/

#include <stdio.h>
#include <stdlib.h>

#include "proto.h"
#include "fasm.h"

/*
** Push filename & position on stack
*/

void Push_File_Status()

{


	strcpy(filename[nest_level], current_filename);

	file_pos[nest_level] = ftell(infile);

	file_line[nest_level++] = current_line_num;

	fclose(infile);


	strcpy(current_filename, operand);
	strcat(current_filename, ".s");

	current_file_pos = 0;

	current_line_num = 0;

	changed = TRUE;

}


/*
** Pop filename & position off stack
*/

void Pop_File_Status()

{

	if (nest_level > -1) {

		strcpy(current_filename, filename[--nest_level]);

		current_file_pos = file_pos[nest_level];

		current_line_num = file_line[nest_level];
		}

}