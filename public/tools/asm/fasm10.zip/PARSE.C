
/*
** FASM - 6502 assembler
** Copyright (c) 2000 by Toshiyasu Morita
** Released under the terms of the GNU Public License
** See the file COPYING for details
*/

/*
** Header files
*/


#include <stdio.h>
#include <stdlib.h>

#include "proto.h"
#include "fasm.h"

/*
** Get a line from input stream
*/

int fgetln()

{
	char c = NULL;
	char *string = current_line_buf;

	int length = 0;



	while ( (c != '\n') && (c != EOF) )

		if (length < 256) {

			if ( (c = fgetc(infile)) == '\t')
				*string++ = ' ';
			else
				*string++ = c;

			length++;
			}

	*--string = NULL;

	return(length);

}


/*
** Analyze line
*/

void Analyze_Line()

{
	char *string = current_line_buf;
	char *dest, *last_char;


	dest = label;

	while ((*string != ' ') && (*string != ';') && (*string != EOF) && *string)

		*dest++ = *string++;

	*dest = NULL;

	label_length = strlen(label);



	while ((*string == ' ') && (*string != ';') && (*string != EOF) && *string)
		string++;

	dest = operator;

	while ((*string != ' ') && (*string != ';') && (*string != EOF) && *string)

		*dest++ = *string++;

	*dest = NULL;

	operator_length = strlen(operator);



	while ((*string == ' ') && (*string != ';') && (*string != EOF) && *string)
		string++;

	dest = last_char = operand;

	while ((*string != ';') && (*string != EOF) && *string) {

		if ((*string != ' ') && (*string != '\t'))

			last_char = dest;

		*dest++ = *string++;
		}

	*dest = NULL;

	*++last_char = NULL;

	operand_length = strlen(operand);



	while ((*string == ' ') && (*string != ';') && (*string != EOF) && *string)
		string++;

	dest = comment;

	while ((*string != EOF) && *string)

		*dest++ = *string++;

	*dest = NULL;

	comment_length = strlen(comment);

}


/*
** Print line
*/

void Print_Line_Pass1()

{
	int i, j;


	if (!list_flag && error_flag && strcmp(current_filename, last_err_filename) ) {

		printf("\nError(s) in file: %s\n", current_filename);

		strcpy(last_err_filename, current_filename);
		}

	if (list_flag || error_flag) {

		printf("%1d %5d ", nest_level, current_line_num);

		printf("%.2x/", (current_address >> 16) & 0x0ff);
		printf("%.4x: ", current_address & 0x0ffff);

		for (i=0; i<4; i++)

			if (byte_len > i)

				printf("%.2x ", byte[i] & 0x0ff);

	   		else

				printf("   ");

		if (label_length || operator_length || operand_length)

			printf("%-17s %-8s %-17s %-.255s\n", label, operator, operand, comment);

		else

			printf("%.80s\n", comment);


		if (byte_len > i) {

	   		while (byte_len > i) {

				printf("        ");
				printf("%.2x/", ( (current_address + i) >> 16) & 0x0ff);
				printf("%.4x: ", (current_address + i) & 0x0ffff);


				for (j=0; j<6; j++)

					if (byte_len > i)

						printf("%.2x ", byte[i++] & 0x0ff);

				printf("\n");
				}

			}
		}



	if (error_flag || severe_error_flag) {

		printf("Error: %s\n", error_text);

		total_errors++;
		}

	if (severe_error_flag)

		exit(ERROR);


}


/*
** Skip spaces/tabs
*/


char *Skip_Spaces(char *buffer)

{

	while ( (*buffer != ' ') && (*buffer) )
		buffer++;

	while ( (*buffer == ' ') && (*buffer) )
		buffer++;

	return(buffer);

}

/*
** Skip past leading spaces/tabs
*/

char *Skip_Leading_Spaces(char *buffer) {

	while ( (*buffer == ' ') && (*buffer) )

		buffer++;



	return(buffer);

}