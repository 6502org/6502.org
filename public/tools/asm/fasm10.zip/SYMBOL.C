
/*
** FASM - 6502 assembler
** Copyright (c) 2000 by Toshiyasu Morita
** Released under the terms of the GNU Public License
** See the file COPYING for details
*/

/*
** Header files
*/

#include <stdio.h>
#include <stdlib.h>

#include "proto.h"
#include "fasm.h"

/*
** Local variables
*/


typedef struct NODE {

	char *label;
	long value;
	struct NODE *next;


} NODE;


NODE *symbol_bucket[4096];



/*
** Clear symbols from linked list
**
** Arguments: None
**
**   Returns: None
*/

void Clear_Symbol()

{
	int i;


	for (i=0; i<4096; symbol_bucket[i++] = NULL);
}



/*
** Calculate 12 bit XOR hash of a string
**
** Arguments: Pointer to a null-terminated string
**
**   Returns: Int (hash value)
*/

int Calculate_Hash(char *string)

{
	int hash = 0, len = 0;


	while (*string) {

		hash ^= *string++;

		hash <<= 1;

		if (hash & 0x1000)
			hash = (hash & 0xffe) | 1;

		len++;

		}

	return(hash);
}



/*
** Add symbol & value to linked list
**
** Arguments: Pointer to null-terminated string and long
**
**   Returns: None
*/

void Add_Symbol(char *label, long value)

{
	char *char_pntr;

	int i, hash;

	NODE *temp, *node_pntr;



	char_pntr = malloc(strlen(label)+1); /* make a copy of label */

	strcpy(char_pntr, label);


	node_pntr = malloc(sizeof(NODE));	/* Create a node */

	node_pntr->label = char_pntr;

	node_pntr->value = value;


	hash = Calculate_Hash(label);			/* Add node to linked list */


	node_pntr->next = symbol_bucket[hash];

	symbol_bucket[hash] = node_pntr;

}



/*
** Find a symbol & value in linked list
**
** Arguments: Pointer to a symbol
**
**   Returns: Value of symbol
*/

long Find_Symbol(char *label)

{
	int hash;

	NODE *temp;

	hash = Calculate_Hash(label);



	if (temp = symbol_bucket[hash]) {

		while (temp) {

			if (!strcmp(temp->label, label))
				return (temp->value);

			else
				temp = temp->next;

			}

		return(UNKNOWN);
		}

	else
		return(UNKNOWN);

}



/*
** Debug symbol table
*/

void Debug_Symbol_Table()

{

	NODE *temp;

	int i;

	printf("\n\nSymbol table dump: \n\n");

	for	(i=0; i<4096; i++)

		if (temp = symbol_bucket[i]) {

			printf("(hash: %d)  ", i);

			while (temp) {

				printf("-> %s ", temp->label);
				printf("($%.2x/", ( (temp->value) >> 16) & 0x0ff );
				printf("%.4x) ", (temp->value) & 0x0ffff);

				temp = temp->next;

				}

			printf("\n");

			}

}

/*
** Output symbol table
*/

void Output_Symbol_Table()

{
	int i;

	NODE *temp;

	char *source, *dest, string[256];



	total_symbols = 0;

	for (i=0; i<4096; i++) {

		if (temp = symbol_bucket[i])

			while (temp) {

				source = temp->label;
				dest = string;

				while (*source)
					*dest++ = toupper(*source++);

				*dest = NULL;

				fprintf(outfile, "SA %s %.4x 0 17 2 0\n", string, temp->value);

				total_symbols++;

				temp = temp->next;
				}
		}

}