
/*
** FASM - 6502 assembler
** Copyright (c) 2000 by Toshiyasu Morita
** Released under the terms of the GNU Public License
** See the file COPYING for details
*/

/*
** Header files
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "proto.h"
#include "fasm.h"

/*
** Identify character type for addressing mode analyzer
*/

int Identify_Character_AddrMode(char c)

{

	/* a/A   returns 5  */
	/* x/X   returns 6  */
	/* y/Y   returns 7  */
	/* #     returns 1  */
	/* (     returns 2  */
	/* )     returns 3  */
	/* ,     returns 4  */
	/* <     returns 8  */
	/* >     returns 9  */
	/* ^     returns 10 */
	/* 00    returns 11 */
	/* -+_$% returns 0  */
	/* a-z   returns 0  */
	/* A-Z   returns 0  */
	/* 0-9   returns 0  */

	static char char_type[128] = {


		/*  00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f   */

/* $00 */	11,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  /* $00 */
/* $10 */	-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  /* $10 */
/* $20 */	-1,-1,-1, 1, 0, 0,-1,-1, 2, 3,-1, 0, 4, 0,-1,-1,  /* $20 */
/* $30 */	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,-1,-1, 8,-1, 9,-1,  /* $30 */
/* $40 */	-1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* $40 */
/* $50 */	 0, 0, 0, 0, 0, 0, 0, 0, 6, 7, 0,-1,-1,-1,10, 0,  /* $50 */
/* $60 */	-1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  /* $60 */
/* $70 */	 0, 0, 0, 0, 0, 0, 0, 0, 6, 7, 0,-1,-1,-1,-1,-1,  /* $70 */

  	};

	return(char_type[c]);

}


/*
** Return rightmost n characters of string
*/

int strright(char *dest, char *src, int len)

{
	int i;


	if (strlen(src) >= len) {

		src = src + strlen(src) - len;

		for (i=0; i<len; i++)

			*dest++ = *src++;

		*dest = NULL;
		}

}

/*
** Copy n characters of string & null-terminate
*/

void strncpy2(char *dest, char *src, int length)


{
	while (length--)

		*dest++ = *src++;

	*dest = NULL;
}



int Identify_Addr_Mode()

{
	int length, type = 0;



	*label2 = NULL;

	switch(length = strlen(operand)) {

		case 0:

			return(label2_length = 0);		/* implied */

		case 1:

			if ( tolower(*operand) == 'a' && (length == 1) ) {

				label2_length = 0; 			/* accumulator */
				return(1);
				}

			/* falls into default */

		default:

			*label2 = NULL;

			switch (*operand) {

				case '#':

					if (!strncmp(operand, "#low ", 5)) {

						type = 9;						/* immediate low */
						strcpy(label2, operand+5);
						}

					else
						if (!strncmp(operand, "#high ", 6)) {

							type = 10;          			/* immediate high */
							strcpy(label2, operand+6);
							}

						else
							if (!strncmp(operand, "#seg ", 5)) {

								type = 11;
								strcpy(label2, operand+5);
								}

							else {

								type = 2;				/* immediate */
								strcpy(label2, operand+1);
								}

					break;


				case '(':

					strright(alt_buffer, operand, 3);

					strlwr(alt_buffer);

					if (!strcmp(alt_buffer, ",x)")) {

						type = 7;		              	/* (ZP,X) */
						strncpy2(label2, operand+1, length-4);
						}

					else

						if (!strcmp(alt_buffer, "),y")) {

							type = 8;             			/* (ZP),Y */
							strncpy2(label2, operand+1, length-4);
							}

						else {

							strright(alt_buffer, operand, 1);

							if (*alt_buffer == ')') {

								type = 6;            			/* (ABS) */
								strncpy2(label2, operand+1, length-2);
								}
							}

					break;


				default:

					strright(alt_buffer, operand, 2);

					strlwr(alt_buffer);

					if (!strcmp(alt_buffer, ",x")) {

						type = 4;    					/* ABS,X/ZP,X */
						strncpy2(label2, operand, length-2);
						break;
						}

					if (!strcmp(alt_buffer, ",y")) {

						type = 5;                 		/* ABS,Y/ZP,Y */
						strncpy2(label2, operand, length-2);
						break;
						}

					type = 3;          					/* ABS/ZP */
					strcpy(label2, operand);
					break;


				}

			break;
		}

		if ( !(label2_length = strlen(label2)) )

			type = ERROR;

		return(type);

}




/*
** Identify addressing mode of instruction
*/

int Identify_Addr_Mode2()


{

	char c, *string = operand;
	int char_type, state = 0;


	static char table[22][12] = {

			/*       AN  #  (  )  ,  A  X  Y  <  >  ^   00  */

			/*  0 */  4, 2, 8, 0, 0, 1, 4, 4, 0, 0, 0, 100,  /* implied     */
			/*  1 */  4, 0, 0, 0, 0, 4, 4, 4, 0, 0, 0, 101,  /* accumulator */
			/*  2 */  3, 0, 0, 0, 0, 3, 3, 3,16,18,20,   0,
			/*  3 */  3, 0, 0, 0, 0, 3, 3, 3, 0, 0, 0, 102,  /* immediate   */
			/*  4 */  4, 0, 0, 0, 5, 4, 4, 4, 0, 0, 0, 103,  /* ABS/ZP      */
			/*  5 */  0, 0, 0, 0, 0, 0, 6, 7, 0, 0, 0,   0,
			/*  6 */  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 104,  /* ABS,X/ZP,X  */
			/*  7 */  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 105,  /* ABS,Y/ZP,Y  */
			/*  8 */  9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,   0,
			/*  9 */  9, 0, 0,10,11, 0, 9, 9, 0, 0, 0,   0,
			/* 10 */  0, 0, 0, 0,14, 0, 0, 0, 0, 0, 0, 106,  /* (ABS)       */
			/* 11 */  0, 0, 0, 0, 0, 0,12, 0, 0, 0, 0,   0,
			/* 12 */  0, 0, 0,13, 0, 0, 0, 0, 0, 0, 0,   0,
			/* 13 */  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 107,  /* (ZP,X)      */
			/* 14 */  0, 0, 0, 0, 0, 0, 0,15, 0, 0, 0,   0,
			/* 15 */  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 108,  /* (ZP),Y      */
			/* 16 */ 17, 0, 0, 0, 0,17,17,17, 0, 0, 0,   0,
			/* 17 */ 17, 0, 0, 0, 0,17,17,17, 0, 0, 0, 109,  /* immediate low */
			/* 18 */ 19, 0, 0, 0, 0,19,19,19, 0, 0, 0,   0,
			/* 19 */ 19, 0, 0, 0, 0,19,19,19, 0, 0, 0, 110,  /* immediate high */
			/* 20 */ 21, 0, 0, 0, 0,21,21,21, 0, 0, 0,   0,
			/* 21 */ 21, 0, 0, 0, 0,21,21,21, 0, 0, 0, 111   /* immediate bank */

			};

							  /* 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 */

	static char important[22] = {0,1,0,1,1,0,0,0,0,1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1 };

	label2_length = 0;
	*label2 = NULL;

	if (!strncmp(string, "#low", 5)) {

		strcpy(label2, comment);
		label2_length = strlen(label2);
		return(9);
		}

	if (!strncmp(string, "#high", 6)) {

		strcpy(label2, comment);
		label2_length = strlen(label2);
		return(10);
		}

	if (!strncmp(string, "#seg", 5)) {

		strcpy(label2, comment);
		label2_length = strlen(label2);
		return(11);
		}

	while ( (char_type = Identify_Character_AddrMode(c = *string++)) != -1)  {

		state = table[state][char_type];

		if (state > 99) {
			label2[label2_length] = NULL;
			return (state - 100);
			}

		if (state == 0) {
			label2[label2_length] = NULL;
			return(-1);
			}

		if ( important[state] )

			label2[label2_length++] = c;


		}

	label2[label2_length] = NULL;
	return(-1);

}


/*
** Encode addressing mode
*/

void Encode_Addr_Mode()

{
	long temp;


	switch(label2_type) {


		case 0:

			byte_len = 1;

			break;


		case 1:

			byte[1] = label2_addr & 0x0ff;

			byte_len = 2;

			break;


		case 2:

			byte[1] = label2_addr & 0x0ff;
			byte[2] = (label2_addr >> 8) & 0x0ff;

			byte_len = 3;

			break;


		case 3:

			if (label2_addr != -1)

				temp = label2_addr - current_address - 2;

				if ( ((temp > 128) || (temp < -127)) && (pass == 2) ) {

					printf("Branch out of range\n");

					}

				byte[1] = temp & 0x0ff;
				byte_len = 2;

				break;


		case 4: 	/* immediate low */

			byte[1] = label2_addr & 0x0ff;

			byte_len = 2;

			break;


		case 5:		/* immediate high */

			byte[1] = (label2_addr >> 8) & 0x0ff;

			byte_len = 2;

			break;

		case 6:		/* immediate bank */

			byte[1] = (label2_addr >> 16) & 0x0ff;

			byte_len = 2;

			break;

		default:

			printf("Internal Assembler Error!\n");
			printf("Encode_Addr_Mode: Unknown label2_type!\n");

			byte_len = 1;

			break;
		}
}
