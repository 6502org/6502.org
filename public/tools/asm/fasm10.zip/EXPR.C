
/*
** FASM - 6502 assembler
** Copyright (c) 2000 by Toshiyasu Morita
** Released under the terms of the GNU Public License
** See the file COPYING for details
*/

/*
** Header files
*/

#include <stdio.h>
#include <stdlib.h>

#include "proto.h"
#include "fasm.h"

/*
** Identify character type for expression analyzer
*/

int Identify_Char_Expr(char c)

{
	/*	a-f   returns 0
	 	A-F   returns 0
	 	_     returns 1
		g-z   returns 1
	 	G-Z   returns 1
	 	0-9   returns 2
	 	$     returns 3
	 	+     returns 4
	 	-     returns 4
		NULL  returns 99	*/

	static char char_type[128] = {


		/*  00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f   */

/* $00 */	99,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  /* $00 */
/* $10 */	-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,  /* $10 */
/* $20 */	-1,-1,-1,-1, 3,-1,-1,-1,-1,-1,-1, 4,-1, 4,-1,-1,  /* $20 */
/* $30 */	 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,-1,-1,-1,-1,-1,-1,  /* $30 */
/* $40 */	-1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1,  /* $40 */
/* $50 */	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,-1,-1,-1,-1, 1,  /* $50 */
/* $60 */	-1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1,  /* $60 */
/* $70 */	 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,-1,-1,-1,-1,-1,  /* $70 */

	};

	return(char_type[c]);
}


/*
** Process value
*/

long Get_Value()

{
	char c;

	char *dest = alt_buffer;

	int digits = 0, type;

	long value = 0;



	if (*global_pntr)

		switch(Identify_Char_Expr(*global_pntr)) {


			case 0:		/* Alphanumeric character - label */
			case 1:

				while ( Identify_Char_Expr(*global_pntr) <= 2 )

					*dest++ = *global_pntr++;

				*dest = NULL;

				return(Find_Symbol(alt_buffer));



			case 2:		/* Numeric character - decimal constant */

				while ( Identify_Char_Expr(*global_pntr) == 2 ) {

					value *= 10;

					value += *global_pntr++ - '0';

					}

				return(value);



			case 3:		/* $ sign - hexadecimal constant */

				global_pntr++;

				type = Identify_Char_Expr(c = *global_pntr);

				while ( (!type) || (type == 2) ) {

					digits++;

					value *= 16;

					if ( (c >= '0') && (c <= '9') )

						value += *global_pntr - '0';

					else
						if ( (c >= 'a') && (c <= 'f') )

							value += *global_pntr - 'a' + 10;

						else
							if ( (c >= 'A') && (c <= 'F') )

								value += *global_pntr - 'A' + 10;

					type = Identify_Char_Expr(c = (*++global_pntr));

					}

				if (digits)

					return(value);


				else {

					printf("Incomplete hex constant\n");
					printf("($ without following 0-9 or a-f/A-F)\n");

					return(ERROR);
					}


			default:

				printf("Label or constant expected but not found\n");
				return(ERROR);
			}

}





/*
** Expression analyzer
*/

long Expression_Analyzer(char *buffer)

{
	long value, temp;


	global_pntr = buffer;

	if ( (value = Get_Value()) == ERROR )

		return(ERROR);

	global_pntr = Skip_Leading_Spaces(global_pntr);

	while (*global_pntr) {

		if (Identify_Char_Expr(*global_pntr) == 4)

			last_operator = *global_pntr;

		else
			return(ERROR);

		global_pntr = Skip_Leading_Spaces(++global_pntr);

		temp = Get_Value();

		global_pntr = Skip_Leading_Spaces(global_pntr);


		switch(last_operator) {

			case '+':

				value += temp;
				break;


			case '-':

				value -= temp;
				break;


			default:

				printf("Internal Assembler Error!\n");
				printf("Expression_Analyzer: Unknown operator!\n");
				break;
			}
		}

		return(value);
}