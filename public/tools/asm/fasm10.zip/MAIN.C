
/*
** FASM - 6502 assembler
** Copyright (c) 2000 by Toshiyasu Morita
** Released under the terms of the GNU Public License
** See the file COPYING for details
*/

/*
** Header files
*/

#include <stdio.h>
#include <stdlib.h>

#include "proto.h"

/*
** Constants
*/

char header[] = "FASM version 1.0 by Toshiyasu Morita";

#define TRUE -1
#define FALSE 0

#define ERROR -1
#define UNKNOWN -1

/*
** Global data
*/

FILE *infile, *outfile;

char main_filename[40];

char output_filename[40];

char current_filename[40];
char current_line_buf[256];
int  current_line_len;

char label[256];
int  label_length;

char operand[256];
int  operand_length;

char operator[256];
int  operator_length;

char label2[256];
int  label2_length;

int  label2_type;
long label2_addr;

char comment[256];
int  comment_length;

char alt_buffer[256];

char *error_text;
int  error_flag;
int  severe_error_flag;

long total_errors;

long total_symbols;

int  nest_level, pass;

long current_address;

long skip_to_address;

long last_address;

long current_line_num;
long current_file_pos;

char filename[16][40];
long file_pos[16];
long file_line[16];

int  changed;

char *global_pntr;

char last_operator;

int  valid_label;

char byte[16384];
int  byte_len;

int  list_flag;

char last_err_filename[40];

char object_buffer[256];
int  object_buf_bytes;

int  output_format;

/*
** Main
*/


main(int argc, char **argv)

{

	int instruct, pseudo_op;

	int addr_mode;

	long temp_addr;

	long total_lines = 0;


	printf("%s\n", header);

	if (argc != 2) {

		printf("Wrong number of arguments\n");
		exit(-1);
		}

	strcpy(main_filename, argv[1]);

	strcpy(output_filename, main_filename);
	strcat(output_filename, ".aax");

	strcat(main_filename, ".s");
	strcpy(current_filename, main_filename);

	printf(" Input file: %s\n", main_filename);
	printf("Output file: %s\n", output_filename);


	output_format = 0;

	/* Pass One */

	pass = 1;

	printf("\n*** Pass 1 ***\n");

	current_line_num = 1;

	list_flag = FALSE;

	current_address = 512;

	nest_level = 0;

	total_errors = 0;

	*last_err_filename = NULL;

	while(nest_level > -1) {

		if ( (infile = fopen(current_filename, "rt")) == NULL ) {

			printf("Error opening file %s\n", current_filename);
			exit(ERROR);
			}

		else {


			fseek(infile, current_file_pos, 0);

			changed = FALSE;

			while(!feof(infile) && !changed && !severe_error_flag) {

				fgetln();

				Analyze_Line();

				error_flag = severe_error_flag = FALSE;

				skip_to_address = FALSE;

				valid_label = TRUE;

				byte_len = 0;

				if (operator_length)
					if ( (instruct = Identify_Instruction()) == ERROR )

						if ( (pseudo_op = Identify_PseudoOp()) == ERROR ) {

							error_text = "Invalid instruction or pseudo-op";
							error_flag = TRUE;
							}

						else	/* Pseudo-op recognized */

							Do_PseudoOp_Pass1(pseudo_op);

					else { 	/* Instruction recognized */

						addr_mode = Identify_Addr_Mode();

						if ( label2_length && (addr_mode != 1) )

							label2_addr = Expression_Analyzer(label2);


						if (addr_mode != ERROR)
							if ( (byte[0] = Encode_Instruction(instruct, addr_mode)) == ERROR) {

								error_text = "Illegal addressing mode for instruction";
								error_flag = TRUE;
								}

							else

								Encode_Addr_Mode();
						else {

							error_text = "Unknown addressing mode";
							error_flag = TRUE;
							}

						}

				if (label_length && valid_label)

					if (Find_Symbol(label) == UNKNOWN)

						Add_Symbol(label, current_address);

					else {

						error_text = "Redefined label";
						error_flag = TRUE;
						}


				Print_Line_Pass1();

				current_address += byte_len;

				if (skip_to_address != FALSE)
					current_address = skip_to_address;

				current_line_num++;
				}

			if (!changed)
				Pop_File_Status();

			}



		}

	fclose(infile);


	/* Pass Two */

	pass = 2;

	printf("\n*** Pass 2 ***\n");

	current_line_num = 1;

	list_flag = FALSE;

	strcpy(current_filename, main_filename);
	current_file_pos = 0;
	current_line_num = 0;

	Open_Output_Buffer();

	last_address = current_address = 512;

	nest_level = 0;

	while(nest_level > -1) {

		if ( (infile = fopen(current_filename, "rt")) == NULL ) {

			printf("Error opening file %s\n", current_filename);
			exit(ERROR);
			}

		else {

			fseek(infile, current_file_pos, 0);

			changed = FALSE;

			while(!feof(infile) && !changed && !severe_error_flag) {

				fgetln();

				Analyze_Line();

				error_flag = severe_error_flag = FALSE;

				skip_to_address = -1;

				valid_label = TRUE;

				byte_len = 0;

				if (operator_length)
					if ( (instruct = Identify_Instruction()) == ERROR )

						if ( (pseudo_op = Identify_PseudoOp()) == ERROR ) {

							error_text = "Invalid instruction or pseudo-op";
							error_flag = TRUE;
							}

						else 	/* Pseudo-op recognized */

							Do_PseudoOp_Pass2(pseudo_op);

					else {	/* Instruction recognized */

						addr_mode = Identify_Addr_Mode();

						if ( label2_length && (addr_mode != 1) )
							if ( (label2_addr = Expression_Analyzer(label2)) == ERROR) {

								error_text = "Undefined label";
								error_flag = TRUE;
								}

						if (addr_mode != ERROR)
							if ( (byte[0] = Encode_Instruction(instruct, addr_mode)) == ERROR) {

								error_text = "Illegal addressing mode for instruction";
								error_flag = TRUE;
								}

							else

								Encode_Addr_Mode();

						else {

							error_text = "Unknown addressing mode";
							error_flag = TRUE;
							}
						}

				if (label_length && valid_label)

					if ( (temp_addr = Find_Symbol(label)) == UNKNOWN) {

						printf("Internal Assembler Error!\n");
						printf("main: Couldn't find symbol on Pass 2!\n");
						exit(ERROR);
						}

					else

						if (temp_addr != current_address) {

							error_text = "Phase error - zero page not properly defined?";
							error_flag = TRUE;
							}

				Print_Line_Pass1();

				Output_Data();

				current_address += byte_len;

				if (skip_to_address != -1)
					current_address = skip_to_address;

				current_line_num++;
				total_lines++;
				}

			if (!changed)
				Pop_File_Status();

			}



		}

	fclose(infile);

	Flush_Output_Buffer();

	Output_Symbol_Table();

	Close_Output_Buffer();

	if (list_flag)
		Debug_Symbol_Table();

	printf("\n");

	printf("  Lines: %ld\n", total_lines);
	printf("Symbols: %ld\n", total_symbols);
	printf(" Errors: %ld\n", total_errors);

}