#ifndef __config_h
#define __config_h

#define PACKAGE_NAME		"lib6502"
#define	PACKAGE_VERSION		"1.0"
#define PACKAGE_BUGREPORT	"firstName (at) lastName (dot) com"
#define PACKAGE_COPYRIGHT	"Copyright (c) 2005 Ian Piumarta"

#endif /* __config_h */
